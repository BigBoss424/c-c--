#pragma once
#ifndef DEGREE_H
#define DEGREE_H	

enum class Degree {
	NETWORKING, SECURITY, SOFTWARE
};


#endif // !DEGREE_H
